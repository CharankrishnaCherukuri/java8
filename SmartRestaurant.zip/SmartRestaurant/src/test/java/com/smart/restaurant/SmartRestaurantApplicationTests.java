package com.smart.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
