package com.smart.restaurant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smart.restaurant.model.FoodItem;
import com.smart.restaurant.service.FoodItemservice;
import com.smart.restaurant.service.FoodItemserviceImpl;

@RestController
@RequestMapping("/fooditem/admin")

public class FoodItemcontroller {
	@Autowired
	private FoodItemservice foodItemservice;
	// constructors

	public FoodItemcontroller(FoodItemserviceImpl foodItemserviceimpl) {
		super();
		this.foodItemservice = foodItemservice;
	}
	@PostMapping
	public ResponseEntity<FoodItem> createFoodItem(@RequestBody FoodItem foodItem){
		return new ResponseEntity<FoodItem>(foodItemservice.createFoodItem(foodItem),HttpStatus.CREATED);
		
	}
	
	

}
