package com.smart.restaurant.service;

import java.util.List;

import com.smart.restaurant.model.FoodItem;

public interface FoodItemservice {
	//Get all FoodItem
//	List<FoodItem>getAllFoodItem();
	// create the FoodItem
	FoodItem createFoodItem (FoodItem foodItem);

}
