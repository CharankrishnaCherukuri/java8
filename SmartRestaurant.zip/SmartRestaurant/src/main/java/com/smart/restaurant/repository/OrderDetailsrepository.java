package com.smart.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.restaurant.model.OrderDetails;



public interface OrderDetailsrepository extends JpaRepository<OrderDetails,Integer> {

}
