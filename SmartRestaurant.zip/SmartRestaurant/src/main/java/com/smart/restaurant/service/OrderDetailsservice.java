package com.smart.restaurant.service;
import com.smart.restaurant.model.OrderDetails;

public interface OrderDetailsservice {
	//create the OrderDetails
	OrderDetails createOrderDetails (OrderDetails orderDetails);

}
