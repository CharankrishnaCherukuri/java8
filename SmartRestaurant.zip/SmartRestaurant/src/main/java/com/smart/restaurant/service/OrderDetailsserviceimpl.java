package com.smart.restaurant.service;

import org.springframework.stereotype.Service;

import com.smart.restaurant.model.OrderDetails;
import com.smart.restaurant.repository.OrderDetailsrepository;
@Service
//dependency injection
public class OrderDetailsserviceimpl implements OrderDetailsservice {
	// dependency Injection
     private OrderDetailsrepository orderDetailsrepository; 
	
	// constructor to store the values
	public OrderDetailsserviceimpl(OrderDetailsrepository orderDetailsrepository) {
	super();
	this.orderDetailsrepository = orderDetailsrepository;
}
	@Override
	public OrderDetails createOrderDetails(OrderDetails orderDetails) {
		// TODO Auto-generated method stub
		return orderDetailsrepository.save(orderDetails); 
		
		
	}

}
