package com.smart.restaurant.service;

import org.springframework.stereotype.Service;

//import java.util.List;

import com.smart.restaurant.model.FoodItem;
import com.smart.restaurant.repository.FoodItemrepository;

@Service
public class FoodItemserviceImpl implements FoodItemservice {
	//dependency injection
	private FoodItemrepository foodItemrepository;
	//constructor to store the values

	public FoodItemserviceImpl(FoodItemrepository foodItemrepository) {
		super();
		this.foodItemrepository = foodItemrepository;
	}// List all details

	@Override
	public FoodItem createFoodItem(FoodItem foodItem) {
		// TODO Auto-generated method stub
		return foodItemrepository.save(foodItem);
	}

//	@Override
//	public List<FoodItem> getAllFoodItem() {
//		return foodItemrepository.findAll();
//	}

	

	
}
