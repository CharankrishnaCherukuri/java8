package com.smart.restaurant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smart.restaurant.model.OrderDetails;
import com.smart.restaurant.service.OrderDetailsservice;

@RestController
@RequestMapping("/OrderDetails/admin")
public class OrderDetailscontroller {
	@Autowired
	private OrderDetailsservice orderDetailsservice;
	//constructors

	public OrderDetailscontroller(OrderDetailsservice orderDetailsservice) {
		super();
		this.orderDetailsservice = orderDetailsservice;
	}
	@PostMapping
	public ResponseEntity<OrderDetails> createOrderDetails(@RequestBody OrderDetails orderDetails){
		return new ResponseEntity<OrderDetails>(orderDetailsservice.createOrderDetails(orderDetails),HttpStatus.CREATED);
		
	}
	

}
