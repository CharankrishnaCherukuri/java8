package com.smart.restaurant.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderDetails {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
     private int orderid;
    @Column(name="order_item")
    private String orderedItem;
    @Column(name="price")
    private int price;
    @Column(name="time")
    private LocalDateTime time = LocalDateTime.now();
    // parameterized constructors
	public OrderDetails(int orderid, String orderedItem, int price, LocalDateTime time) {
		super();
		this.orderid = orderid;
		this.orderedItem = orderedItem;
		this.price = price;
		this.time = time;
	}
	public OrderDetails() {
		super();
	}
	//getters and setters
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public String getOrderedItem() {
		return orderedItem;
	}
	public void setOrderedItem(String orderedItem) {
		this.orderedItem = orderedItem;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
}
