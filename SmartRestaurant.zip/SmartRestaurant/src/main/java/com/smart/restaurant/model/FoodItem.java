package com.smart.restaurant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FoodItem {
   //data members
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
     private int Fooditemid;
    @Column(name="Fooditemname")
    private String Fooditemname;
    @Column(name="Fooditemprice") 
    private int Fooditemprice;
    @Column(name="Fooditemdescription")
    private String Fooditemdescription;
    // parameterized constructors
	public FoodItem(int fooditemid, String fooditemname, int fooditemprice, String fooditemdescription) {
		super();
		Fooditemid = fooditemid;
		Fooditemname = fooditemname;
		Fooditemprice = fooditemprice;
		Fooditemdescription = fooditemdescription;
	}
	// default constructors
	public FoodItem() {
		super();
	}
	//getters and setters
	public int getFooditemid() {
		return Fooditemid;
	}
	public void setFooditemid(int fooditemid) {
		Fooditemid = fooditemid;
	}
	public String getFooditemname() {
		return Fooditemname;
	}
	public void setFooditemname(String fooditemname) {
		Fooditemname = fooditemname;
	}
	public int getFooditemprice() {
		return Fooditemprice;
	}
	public void setFooditemprice(int fooditemprice) {
		Fooditemprice = fooditemprice;
	}
	public String getFooditemdescription() {
		return Fooditemdescription;
	}
	public void setFooditemdescription(String fooditemdescription) {
		Fooditemdescription = fooditemdescription;
	}
	

}